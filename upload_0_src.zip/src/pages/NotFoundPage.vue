

<template>
    <div class="not-found-container">
      <h1>404 Not Found</h1>
      <p>Sorry, the page you are looking for does not exist.</p>
    </div>
  </template>
  
  <style scoped>
    .not-found-container {
      text-align: center;
      margin-top: 50px;
    }
  
    h1 {
      font-size: 2em;
      color: #ff4d4f;
    }
  
    p {
      font-size: 1.2em;
      color: #333;
    }
  </style>
  