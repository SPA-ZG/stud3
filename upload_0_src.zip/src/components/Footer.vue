<template>
    <footer>
      <p>Movies are the best</p>
    </footer>
  </template>
  
  <style scoped>
  footer {
    background-color: rgba(0, 0, 0, .8);;
    padding: 10px;
    text-align: center;
    position: fixed;
    bottom: 0;
    width: 100%;
  }
  </style>
  